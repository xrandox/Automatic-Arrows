name = "Blish HUD Pathing Module Lua"

files = {
    "pack.lua"
}