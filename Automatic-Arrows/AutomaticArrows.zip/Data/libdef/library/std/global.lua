---@meta

---@deprecated # This is not supported.  Use Pack:Require(path) instead.
function _G.require(path) end