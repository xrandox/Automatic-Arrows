---@meta

---@class IBehavior
local IBehavior = {}